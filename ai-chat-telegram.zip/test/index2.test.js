const escapeBacktickInCode = (markdownString) => {
    // Mencari blok kode dalam format markdown
    const codeBlocks = markdownString.match(/```[\s\S]*?```/g);

    // Jika terdapat blok kode, lakukan penggantian backtick di dalamnya
    if (codeBlocks) {
        codeBlocks.forEach((codeBlock) => {
            const escapedCodeBlock = codeBlock.replace(/`/g, "\\`");
            markdownString = markdownString.replace(codeBlock, escapedCodeBlock);
        });
    }

    return markdownString;
};

test("escapeBacktickInCode", () => {
    expect(escapeBacktickInCode("console.log(`${1+2}`)")).toEqual("console.log(`${1+2}`)");
    expect(escapeBacktickInCode("```javascript" + "\n" + "console.log(`${1+2}`)" + "\n" + "```")).toEqual("```javascript" + "\n" + "console.log(\\`${1+2}\\`)" + "\n" + "```");
    expect(escapeBacktickInCode("```js" + "\n" + "console.log(`${1+2}`)" + "\n" + "```")).toEqual("```js" + "\n" + "console.log(\\`${1+2}\\`)" + "\n" + "```");
    expect(escapeBacktickInCode("```javascript" + "\n" + "const name = \"Alex\"; console.log(`My name is ${name}`);" + "\n" + "```")).toEqual("```javascript" + "\n" + "const name = \"Alex\"; console.log(\\`My name is ${name}\\`);" + "\n" + "```");
    expect(escapeBacktickInCode("```js" + "\n" + "const name = \"Alex\"; console.log(`My name is ${name}`);" + "\n" + "```")).toEqual("```js" + "\n" + "const name = \"Alex\"; console.log(\\`My name is ${name}\\`);" + "\n" + "```");
});