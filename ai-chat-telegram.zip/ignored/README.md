### Chat object

```javascript
{
  message_id: 4,
  from: {
    id: 123456789,
    is_bot: false,
    first_name: 'M',
    last_name: 'Johny Any',
    username: 'abc',
    language_code: 'en'
  },
  chat: {
    id: 123456789,
    first_name: 'M',
    last_name: 'Johny Any',
    username: 'abc',
    type: 'private'
  },
  date: 1703500819,
  text: '/help',
  entities: [ { offset: 0, length: 5, type: 'bot_command' } ]
}
```

### When user sends a photo
```javascript
{
  message_id: 13,
  from: {
    id: 1800553434,
    is_bot: false,
    first_name: 'Mohamad',
    last_name: 'Bima Yudha',
    username: 'm_bima_y',
    language_code: 'en'
  },
  chat: {
    id: 1800553434,
    first_name: 'Mohamad',
    last_name: 'Bima Yudha',
    username: 'm_bima_y',
    type: 'private'
  },
  date: 1703662711,
  photo: [
    {
      file_id: 'AgACAgUAAxkBAAMNZYvUd1cvd6PprL8cQblsvwVTSSQAAt-3MRvd1WBUhUW1bze8ZwQBAAMCAANzAAMzBA',
      file_unique_id: 'AQAD37cxG93VYFR4',
      file_size: 942,
      width: 90,
      height: 66
    },
    {
      file_id: 'AgACAgUAAxkBAAMNZYvUd1cvd6PprL8cQblsvwVTSSQAAt-3MRvd1WBUhUW1bze8ZwQBAAMCAANtAAMzBA',
      file_unique_id: 'AQAD37cxG93VYFRy',
      file_size: 11072,
      width: 320,
      height: 233
    },
    {
      file_id: 'AgACAgUAAxkBAAMNZYvUd1cvd6PprL8cQblsvwVTSSQAAt-3MRvd1WBUhUW1bze8ZwQBAAMCAAN4AAMzBA',
      file_unique_id: 'AQAD37cxG93VYFR9',
      file_size: 29507,
      width: 575,
      height: 419
    }
  ],
  caption: 'He'
}
{ type: 'photo' }
```

### Users collection
- for gemini-pro only
```js
...
{
  id: 1800553434,
  first_name: 'Mohamad',
  last_name: 'Bima Yudha',
  username: 'm_bima_y',
  type: 'private',
  is_bot: false,
  language_code: 'en',
  date: 1703662711,
  history: [
    {
      role: "user",
      parts: "Hello, I have 2 dogs in my house.",
    },
    {
      role: "model",
      parts: "Great to meet you. What would you like to know?",
    },
  ],
}
...
```

### Cleared histories collection
- for gemini-pro only

```js
...
{
  id: 1800553434,
  histories: [
    [
      {
      role: "user",
      parts: "Hello, I have 2 dogs in my house.",
      },
      {
        role: "model",
        parts: "Great to meet you. What would you like to know?",
      },
    ],
    [
      {
      role: "user",
      parts: "Hello, I have 2 dogs in my house.",
      },
      {
        role: "model",
        parts: "Great to meet you. What would you like to know?",
      },
    ],
  ]
}
...
```
### History collection

```js
{
  "_id": {
    "$oid": "659241e01e19504619622176"
  },
  "chatId": {
    "$numberInt": "1800553434"
  },
  "firstName": "Mohamad",
  "lastName": "Bima Yudha",
  "username": "m_bima_y",
  "type": "private",
  "isBot": false,
  "languageCode": "en",
  "date": {
    "$numberInt": "1704083930"
  },
  "history": [
    {
      "role": "user",
      "parts": "Halo",
      "_id": {
        "$oid": "659241e01e19504619622177"
      }
    },
    {
      "role": "model",
      "parts": "Halo juga! Apa kabar hari ini?",
      "_id": {
        "$oid": "659241e01e19504619622178"
      }
    },
    {
      "role": "user",
      "parts": "Selamat tahun baru 2024!",
      "_id": {
        "$oid": "659241f01e1950461962217f"
      }
    },
    {
      "role": "model",
      "parts": "Selamat tahun baru 2024 juga untuk Anda! Semoga tahun ini membawa banyak kebahagiaan, kesehatan, dan kesuksesan untuk Anda dan orang-orang terkasih.",
      "_id": {
        "$oid": "659241f01e19504619622180"
      }
    },
    {
      "role": "user",
      "parts": "Buatkan resolusi tahun baru",
      "_id": {
        "$oid": "6592420d1e1950461962218b"
      }
    },
    {
      "role": "model",
      "parts": "**Resolusi Tahun Baru 2024:**\n\n* **Kesehatan:**\n    * Olahraga secara teratur, minimal 30 menit setiap hari.\n    * Makan makanan yang lebih sehat, seperti buah-buahan, sayur-sayuran, dan biji-bijian utuh.\n    * Kurangi konsumsi makanan olahan, minuman manis, dan alkohol.\n    * Tidur yang cukup, sekitar 7-8 jam setiap malam.\n    * Kelola stres dengan baik, seperti dengan meditasi, yoga, atau menghabiskan waktu di alam.\n\n* **Karier:**\n    * Tetapkan tujuan karier yang jelas dan buat rencana untuk mencapainya.\n    * Tingkatkan keterampilan dan pengetahuan dengan mengikuti kursus atau pelatihan.\n    * Bangun jaringan profesional yang kuat.\n    * Cari peluang untuk promosi atau kemajuan karier.\n\n* **Keuangan:**\n    * Buat anggaran dan patuhi anggaran tersebut.\n    * Bayar tagihan tepat waktu dan lunasi utang.\n    * Sisihkan uang untuk tabungan dan investasi.\n    * Cari cara untuk menambah penghasilan, seperti dengan pekerjaan sampingan atau investasi.\n\n* **Hubungan:**\n    * Luangkan lebih banyak waktu untuk keluarga dan teman-teman.\n    * Perbaiki komunikasi dan hubungan dengan orang-orang terdekat.\n    * Bersikap lebih pengertian dan suportif terhadap orang lain.\n    * Bangun hubungan baru yang positif dan bermakna.\n\n* **Pribadi:**\n    * Belajar sesuatu yang baru dan menantang.\n    * Ambil lebih banyak risiko dan keluar dari zona nyaman.\n    * Bersikap lebih positif dan optimis dalam menghadapi hidup.\n    * Bantu orang lain dan berkontribusi pada komunitas.\n    * Nikmati hidup dan jangan lupa untuk bersenang-senang!",
      "_id": {
        "$oid": "6592420d1e1950461962218c"
      }
    }
  ],
  "__v": {
    "$numberInt": "0"
  }
}
```