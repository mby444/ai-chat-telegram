(async () => {
    const rawData = await fetch(`https://api.telegram.org/file/bot6438108768:AAE05Jk2sqKetjUE7Ov3-q3gBW42DpBnCNU/photos/file_0.jpg`);
    const data = await rawData.blob();
    console.log(data)
    console.log(data.toString("base64"))
})();